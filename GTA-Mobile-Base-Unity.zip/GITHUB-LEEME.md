# Tucumán Abierto - paquete para GitHub

Este paquete conserva el proyecto Unity base recibido, incluyendo Assets/Scripts, Packages, ProjectSettings, el workflow de GitHub Actions y el script de compilación Android del Editor.

## Subida
1. Descarga y descomprime este ZIP en tu computadora.
2. Sube el CONTENIDO de la carpeta descomprimida a la raíz del repositorio GitHub (no subas el ZIP como un único archivo).
3. Comprueba que `.github/workflows/build-android.yml` quede en esa ruta exacta.
4. En GitHub configura los secretos UNITY_LICENSE, UNITY_EMAIL y UNITY_PASSWORD. Nunca subas el archivo .ulf ni contraseñas al repositorio.
5. Ejecuta Actions > Build Android APK.

## Alcance
Este es el proyecto base preparado para GitHub. Incluye el mundo urbano estilizado que ya traía el ZIP original y sus scripts. NO incluye todavía una réplica fotorrealista de toda la provincia, modelos detallados de personajes/autos ni edificios fotogramétricos. Eso requiere una ampliación posterior con assets y datos geográficos autorizados.
